# MItamae binary for Centos 6 (x86_64)

## Usage

```sh
$ vagrant up
$ vagrant ssh
$ bash /vagrant/build.sh
```
